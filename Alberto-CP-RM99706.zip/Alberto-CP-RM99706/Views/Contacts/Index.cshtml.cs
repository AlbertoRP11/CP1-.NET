using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Alberto_CP_RM99706.Views.Contacts
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
