using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Alberto_CP_RM99706.Views.Login
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
