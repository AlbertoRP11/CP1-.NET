using Alberto_CP_RM99706.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Alberto_CP_RM99706.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        private User user = new User();

        public IActionResult Index()
        {
            ViewBag.User = user;
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
