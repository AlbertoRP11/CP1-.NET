﻿using Microsoft.AspNetCore.Mvc;

namespace Alberto_CP_RM99706.Controllers
{
    public class ContactsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
