﻿namespace Alberto_CP_RM99706.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; } = "Alberto";
        public string Email { get; set; } = "alberto@email.com";
        public string Password { get; set; } = "123456";
        public string Materia { get; set; } = "Advanced Business Development with .NET";
    }
}
